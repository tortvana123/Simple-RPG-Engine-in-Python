# Cell-Based Text-Adventure Engine
# A text game engine, with a simple GUI interface, 
# made with the intent of making these games as easy as possible to make.
# Author: Alex Vreimann
# Licence: MIT


# --------
# Imports
# --------

from appJar import gui
import ruamel.yaml as yaml
from time import sleep


# --------
# Global Variables
# --------

# ----
# A dictionary for containing room instances.
# ----
rooms = {} 

# ----
# Dictionary for configuration file filenames and variables to store the data deserialized from them.
# ----
files = {"general_data" : "general_data.yaml"}
general_data = {}


# -------
# Functions
# -------

# ----
# YAML de-/serializing, compatible with older and newer versions of ruamel.yaml (Works with 0.15.35)
# ----

def yaml_io(action, istream=None):  # ser_type - "serialize" data into YAML or "deserialize" data from YAML; istream - input data
    ostream = ""

    if yaml.version_info < (0, 15): # Versions before 0.15 used a different syntax.
        if action == "deserialize":
            ostream = yaml.safe_load(istream)
            return ostream
        elif action == "serialize":
            yaml.safe_dump(istream, ostream)
            return ostream
    else:
        yml = yaml.YAML(typ='safe', pure=True) # Using the new syntax.
        if action == "deserialize":
            ostream = yml.load(istream)
            return ostream
        elif action == "serialize":
            yml.dump(istream, ostream)
            return ostream

# ----
# SystemExit alias
# ----

def quit_game():
    raise SystemExit

# ----
# Button function - Start/Stop Program
# ----
def start_btn(button):
    if button == "Start Game": # Not implemented yet.
        print("not implemented.")
    elif button == "Quit":
        quit_game()

# ----
# Load Game Data (TBD: Figure out how to implement progress meters properly.)
# ----

def load_data():
    global files
    global general_data
    app.setTitle("Loading Data...")
    # Open files and store the data in variables.
    with open(files["general_data"]) as yaml_data:
        general_data = yaml_io("deserialize", yaml_data)
    app.addLabel("current_import", "Loading title screen info...")

# ----
# Title screen
# ----

def title_screen():
    app.removeAllWidgets()
    print(general_data)
    app.setTitle(general_data["game_title"])
    app.addLabel("title_label", general_data["title_label"])
    app.addLabel("title_description", general_data["title_description"])
    app.addButton("Start Game", start_btn)
    app.addButton("Quit", start_btn)

# --------
# Compatibility for importing this script as a module.
# --------
 
if __name__ == "__main__":  # If this file is being run directly
    with gui() as app: # Start GUI
        load_data() # Load game data
        title_screen()

