# Room class from the original project:
class Room:
    room_amount = 0
    current_room = 0
    
    def __init__(self, id, type, action):  # Data init
        self.id = id
        self.type = type
        self.action = action

    @classmethod
    def generate_room(cls):
        # Make data available from external variables
        global data
        global rooms
        # Add one to the amount of rooms, for assigning an id.
        cls.room_amount += 1
	    #Room properties
        #room_type = choice(data["room_type"])# To do - add chances to room types happening. random.randrange?
        #room_description = choice(data["room_descriptions"])
        # Pick a random number in a range from 0 to 100, for a precentage chance, and pick a room type based on that.

        room_type
        """x = randrange(0, 101)
        if x <= 55:
            room_type = "Monster"
        elif x > 55 and x <= 80 :
            room_type = "Item"
        elif x > 80 and x <= 90:
            room_type = "Store"
        elif x == 91:
            room_type = "Instant Death"
        elif x > 91:
            room_type = "Nothing"
        """
        room_actions = "Something"
        # Initialize object
        rooms[cls.room_amount] = Room(cls.room_amount, room_type, room_actions) # 1st is room ID.
        
    def show_room(self):
        app.removeAllWidgets()
        current_room = self.id
        #if self.type != "Store":
         #   if self.type == "Monster":
          #      pass
           # if self.type == "Item":
            #    pass
            #if self.type == "Instant Death":
             #   pass
            #if self.type == "Nothing":
             #   pass
        #elif self.type == "Store":
         #   app.addLabel("Store")
          #  app.addLabel("Still a WIP, please ignore.")
        app.addButton("Select", Room.action)

    @classmethod
    def action(cls, action):
        global data
        print(data)

