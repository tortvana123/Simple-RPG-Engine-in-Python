# Cell-Based Text-Adventure Engine V0.1
A cell-based text-adventure engine, with a simple GUI interface, made with the intent of making these games as easy as possible.

## Progress
### Done
* Implemented data loading
* Implemented title screen
* Implemented a command alias for exiting the game.

### To-Do
* Make a LucidChart explaining what to do and when, in the engine.
* Add a character name screen.
* Add character stats
* When done with transferring everything needed from the previous repo, discard the repo.
